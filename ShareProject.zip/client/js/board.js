Template.board.rendered = function() {
	$("#board-link").addClass('selected');
	$("#files-link").removeClass('selected');
	$("#jokes-link").removeClass('selected');
	$("#rankings-link").removeClass('selected');
	$("#search-link").removeClass('selected');
	$("#login-link").removeClass('selected');
	$("#profile-link").removeClass('selected');

}